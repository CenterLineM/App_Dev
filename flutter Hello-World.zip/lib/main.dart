// Add the English words package and generate a word pairing each
// time the app is hot reloaded.

import 'package:flutter/material.dart';
import 'package:english_words/english_words.dart';

void main() => runApp(new MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final WordPair wordPair = new WordPair.random();

    return new MaterialApp(
      title: 'Welcome to Flutter',
      home: new Scaffold(
        appBar: new AppBar(
          title: const Text(' 歡迎來 Flutter'),
        ),
        body: new Center(
          // child: new Text(wordPair.asPascalCase),
          // 實踐實體方法
          child: new RandomWords(),
        ),
      ),
    );
  }
}

// 創建新類別
class RandomWordsState extends State<RandomWords> {
  // DO : 这表明我们在使用专门用于 RandomWords 的 State 泛型类。
  // 应用的大部分逻辑和状态都在这里 —— 它会维护 RandomWords 控件的状态

  //您将添加一个基本的 build 方法，
  //该方法通过将生成单词对的代码从 MyApp 移动到 RandomWordsState 来生成单词对。

  Widget build(BuildContext context) {
    final WordPair wordPair = new WordPair.random();
    return new Text(wordPair.asPascalCase);
  }
}

// RandomWordsState 依赖 RandomWords
class RandomWords extends StatefulWidget {
  @override
  RandomWordsState createState() => new RandomWordsState();
}
